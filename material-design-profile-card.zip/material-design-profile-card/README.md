# Material Design: Profile Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mestika/pen/KVXVWE](https://codepen.io/Mestika/pen/KVXVWE).

Material Design: Profile Card